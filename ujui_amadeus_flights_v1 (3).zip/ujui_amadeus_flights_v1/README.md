# UJUI Flights – “Cheapest/Best/Fastest” Page (V1)

This package gives you a **real clickable flight-results page** (matching the structure of your screenshot),
plus a **secure backend proxy** (serverless) that talks to Amadeus **Test**.

## What you get
- `frontend/index.html`  – single-file web page (clickable UI + real API wiring)
- `vercel/api/flights/search.ts` – serverless API route (keeps secrets on server)
- `vercel/shared/normalize.ts` – converts Amadeus response into the UI’s clean format

## How it works (high level)
Frontend calls:
POST `/api/flights/search` with:
- origin, destination (IATA), departDate, returnDate, adults, travelClass, maxStops

Backend:
1) Gets OAuth token from Amadeus (client_credentials) and caches it in memory.
2) Calls Amadeus Flight Offers Search.
3) Normalizes to a stable format for UI rendering.
4) Returns JSON to frontend.

## Deploy (minimal human steps)
Someone (assistant/colleague) will do this once:
1) Create a Vercel project from the `vercel/` folder
2) Add environment variables:
   - `AMADEUS_CLIENT_ID` = <your NEW Test Client ID>
   - `AMADEUS_CLIENT_SECRET` = <your NEW Test Client Secret>
   - `AMADEUS_BASE_URL` = https://test.api.amadeus.com
3) Deploy. The site will be live with a URL.

Security rule: Never paste secrets in chat. Only put them into the deploy platform env vars.

## Notes / limits (honest)
- This builds the **results page** experience (filters, sorting, list cards, select).
- “Best” score is a simple weighted formula (price + duration + stops). Can be tuned later.
- For “price confirmation before checkout”, add Amadeus Flight Offers Price in Phase 2.
